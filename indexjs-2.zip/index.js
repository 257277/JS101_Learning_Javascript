var name="Rahul sharma";
var age=24;
console.log(name +" "+ typeof(name));
console.log(age +" "+ typeof(age));