var stored_username = "abc@gmail.com";
var stored_password = 12345;

var input_username = "abc@gmail.com";
var input_password = 123456;

if (stored_username != input_username && stored_password == input_password) {
  console.log("Incorrect username");
}
else if (stored_username == input_username && stored_password != input_password) {
  console.log("Incorrect password");
}
else if (stored_username != input_username && stored_password != input_password) {
  console.log("Both Username and password are incoorect");
}
else {
  console.log("Both Username and password are coorect");
}