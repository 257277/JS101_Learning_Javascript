var x="sat";
if(x=="sun")
{
  console.log("sunday");
}
else if(x=="mon")
{
  console.log("Monday");
}
else if(x=="tue")
{
  console.log("Tuesday");
}
else if(x=="wed")
{
  console.log("Wednesday");
}
else if(x=="thu")
{
  console.log("Thursday");
}
else if(x=="fri")
{
  console.log("Friday");
}
else if(x=="sat")
{
  console.log("Saturday");
}