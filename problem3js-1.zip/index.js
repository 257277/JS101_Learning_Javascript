var a=20;
var b=20;
if(a>b)
{
  console.log(a,"is greater than",b);
}
else if(a<b)
{
   console.log(b,"is greater than",a);
}
else
{
  console.log("both equal");
}