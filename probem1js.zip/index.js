let a=0;
if((a%3)==0)
{
  console.log("multiple of 3");
}
else 
{
    console.log("not multiple of 3");
}