
var a=1;
var b=5;
var c=3;
a>b?(a>c?console.log(a):console.log(c)):(b>c?console.log(b):console.log(c));