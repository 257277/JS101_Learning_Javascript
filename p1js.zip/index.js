var yearOfBirth=2009;
var age = 2022-yearOfBirth;
if(age>=13 && age<=19 )
{
  console.log("Teenage");
}
else if(age>=20 && age<=29)
{
  console.log("Twenties");
}