var name= "Rahul sharma";
console.log(name);
name="Rattan Kumar sharma";
console.log(name);
name="Praveen sharma";
console.log(name);