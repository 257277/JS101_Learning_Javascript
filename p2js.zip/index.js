var x="z";
if(x=="a"|| x=="e"||x=="i"|| x=="o"||x=="u")
{
  console.log("Vowel");
}
